Develop a personal finance application that helps you manage your money wisely. The application will ask you to enter an amount you earn in this month (Account #0). This income is
divided into 6 sub-accounts which are described below:

. Account #1: NEC - Necessity - 55% of Account #0
. Account #2: FFA - Finance Freedom Account - 10% of Account #0
. Account #3: EDU - Education - 10 % of Account #0 
. Account #4: LTSS-Long Term Spending Saving - 10% of Account #0 .
. Account #5: PLAY - 10% of Account #0 Account #6: GIVE-5% of Account #0

Here's an example:

Enter your income this month:


Here's how you should manage your money: 5000
5000
NEC: 2750
FFA: 500
EDU: 500
LTSS: 500
PLAY: 500
GIVE: 250

NOTE: Design the money dividing module in a way that is reusable in other applications, e.g. desktop, web and mobile.