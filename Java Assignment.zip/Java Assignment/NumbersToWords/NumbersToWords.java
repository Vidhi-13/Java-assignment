public class Main {
      
static void numbersToWords(char a[])  
{  
int len = a.length;  
if (len == 0)   
{ 
System.out.println("The string is empty!");  
return;  
}  
if (len > 4)   
{  
System.out.println("\n The given number has more than 4 digits!");  
return;  
}  
String[] onedigit = new String[] {"Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};  
String[] twodigits = new String[] {"", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};  
String[] multipleoftens = new String[] {"",  "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};  
String[] poweroftens = new String[] {"Hundred", "Thousand"};  
System.out.print(String.valueOf(a) + ": ");  
  
if (len == 1)   
{  
System.out.println(onedigit[a[0]-'0']);  
return;  
}  
int x = 0;  
while (x < a.length)   
{  
if (len >= 3)   
{  
if (a[x] - '0' != 0)   
{  
System.out.println(onedigit[a[x] - '0'] );  
System.out.println(poweroftens[len - 3] + " " );  
}  
--len;  
}  

else   
{  
if (a[x] - '0' == 1)   
{  
int sum = a[x] - '0' + a[x + 1] - '0';  
System.out.println(twodigits[sum]);  
return;  
}  

else if (a[x] - '0' == 2 && a[x + 1] - '0' == 0)   
{  
System.out.println("Twenty");  
return;  
}  
else   
{  
int i = (a[x] - '0');  
if (i > 0)  
System.out.println(multipleoftens[i]);  
else  
System.out.println("");  
++x;  
if (a[x] - '0' != 0)  
System.out.println(onedigit[a[x] - '0']);  
}  
}  
++x;  
}  
}  
public static void main(String args[])  
{  
numbersToWords("20".toCharArray());  
System.out.println("\n"); 
numbersToWords("86".toCharArray());  
System.out.println("\n"); 
numbersToWords("365".toCharArray());  
System.out.println("\n"); 
numbersToWords("1314".toCharArray());
System.out.println("\n"); 
numbersToWords("0812".toCharArray());  
System.out.println("\n"); 
  
}  
}  

